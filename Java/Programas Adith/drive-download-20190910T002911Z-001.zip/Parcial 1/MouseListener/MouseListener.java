import java.awt.*;
import java.awt.event.*;
import java.awt.event.MouseListener;

import javax.swing.*;

public class MouseListener2 extends JPanel implements  MouseListener {
    JPanel panel = new JPanel();
    JFrame frame = new JFrame();

    public MouseListener2() {
        addMouseListener((MouseListener) this);
        panel.addMouseListener((MouseListener) this);
        frame.addMouseListener((MouseListener) this);
    }
    public static void main(String [] args){
        MouseListener2 play = new MouseListener2();
        play.setPanel();
    }
    public void setPanel(){
        panel.setLayout(null);
        frame.add(panel);
        frame.setLayout(null);
        panel.setBounds(0,0,100,100);
        frame.setVisible(true);
        panel.setVisible(true);
        panel.setFocusable(true);
        frame.setSize(300,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void mousePressed(MouseEvent evt){
        System.out.println("Precionado");
    }
    public void mouseReleased(MouseEvent evt){
        System.out.println("Soltado");
    }
    public void mouseClicked(MouseEvent evt){
        System.out.println("Click");
    }
    public void mouseEntered(MouseEvent evt){
        System.out.println("Entro");
    }
    public void mouseExited(MouseEvent evt){
        System.out.println("Salio");
    }
}