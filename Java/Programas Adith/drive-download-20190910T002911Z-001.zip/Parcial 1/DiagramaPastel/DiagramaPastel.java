import javax.swing.*;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Arc2D;

public class DiagramaPastel extends JFrame {

    public int opcion1 = 0;
    public int opcion2 = 0;
    public int opcion3 = 0;
    private boolean bnd=false;

    public DiagramaPastel() {
        initialize();
    }

    private void initialize() {
        setSize(300, 600);
        setLayout(new FlowLayout(FlowLayout.LEFT));
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JLabel lblPartido = new JLabel("¿Tienes que hacer tarea?");
        getContentPane().add(lblPartido);

        String[] names = new String[]{
                "Si", "No", "Tal vez"
        };
        JComboBox comboBox = new JComboBox<String>(names);
        comboBox.setEditable(true);

        comboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
      
                JComboBox comboBox = (JComboBox) event.getSource();
                Object selected = comboBox.getSelectedItem();
    
                if(selected == "Si")
                    opcion1++;
                if(selected == "No")
                    opcion2++;
                if(selected == "Tal vez")
                    opcion3++;
                bnd=true;
                repaint();
        

            }
        });
        getContentPane().add(comboBox);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new DiagramaPastel().setVisible(true);
            }
        });
    }
    // Graphics2D g2 = (Graphics2D) g;

    public void paint(Graphics g)
    {
        super.paint(g);
        if (bnd==true)
        {
            int suma=opcion1+opcion2+opcion3;

            int grados1=opcion1*360/suma;
            int grados2=opcion2*360/suma;
            int grados3=opcion3*360/suma;

            g.setColor(new Color(23,165,137));
            g.fillArc(50,250,200,200,0,grados1);
            g.fillRect(370,250,20,20);
            g.drawString("Si", 400, 270);            

            g.setColor(new Color(202,111,30));
            g.fillArc(50,250,200,200,grados1,grados2);
            g.fillRect(370,280,20,20);
            g.drawString("No", 400, 300);            

            g.setColor(new Color(241,196,15));
            g.fillArc(50,250,200,200,grados1+grados2,grados3);
            g.fillRect(370,310,20,20);
            g.drawString("Tal vez", 400, 330);        
        }
    }
 
}