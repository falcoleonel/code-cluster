
Pack para pasar Frank
Se recomienda instalar Java 11 y Netbeans 11.2

Contenido:
- Chat: Última práctica del tercer parcial, yo lo hice, está testeado y
        funciona.

- chatServer: Última práctica del tercer parcial, se lo pasaron a Roxana,
              no funciona muy bien, está sólo para referencia.

- Combinaciones: Proyecto de Roxana, funciona, está sólo para referencia.

- Filtros: Proyecto de Leo, funciona, está sólo para referencia.

- ParalelaParcial1-copiados: Proyectos del primer parcial, me los pasó
                             Cristina, algunos no funcionan muy bien, están
                             sólo para referencia.

- Proyectos1erParcial: Son sólo los primeros 2 completos y el 3ro incompleto
                       de los proyectos del primer parcial, yo los hice, los
                       completos están testeados y funcionan.

- PruebaRMI: Práctica del tercer parcial, está testeada y funciona.

- PruebaRMIA: Práctica del tercer parcial de RMI con servidor para registrar
              servicios, está testeada y funciona.

- Sudoku: Proyecto que entregué el tercer parcial, funciona, está sólo para
          referencia.


¿Qué falta?

- Los últimos 2 proyectos del primer parcial (podemos usar los que no sirven).
- Tu proyecto del tercer parcial (ya estoy pensando qué podemos hacer xd).
