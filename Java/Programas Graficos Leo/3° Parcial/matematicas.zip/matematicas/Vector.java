/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matematicas;

/**
 *
 * @author scoral
 * @param <T>
 */
public interface Vector<T> {
    
    public T mas(T v2);
    public T menos(T v2);
    public T por(double f);
    public T entre(double f);
}
